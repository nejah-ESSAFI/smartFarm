#include<gtk/gtk.h>
#include<string.h>
typedef struct
{ 
int jour;
int mois;
int annee;
}date;


typedef struct {
char refcapteur[50];
char type[50];
char etat[50];
char marque[50];
date dda;
char bp[50];
char bs[50];
}capteur;

typedef struct {
char refcapteur[50];
int j;
int m;
int a;
float val;
}valeur;

typedef struct {
float vmin;
float vmax;
}vprob;

typedef struct {
char ter[500];

}term;

void ajouter_capteur(capteur c);
void afficher_capteur(GtkWidget *liste);
void supprimer_capteur(capteur c);
int rechercher(capteur c);
capteur refrechercher(capteur c);
void modifier_capteur(capteur c);
void afficher_capteur(GtkWidget *liste);
void ajouter_temperature(valeur v);
void ajouter_humidite(valeur v);
void afficher_temperature(GtkWidget *liste);
void afficher_humidite(GtkWidget *liste);
void afficher_valeur_capteur(GtkWidget *liste,capteur c);
void afficher_valeur_probleme_hum(GtkWidget *liste,vprob v);
void afficher_valeur_probleme_temp(GtkWidget *liste,vprob v);
void modifier_capteur_en_defectueux(capteur c);
void capteur_valeur_defecteux_temp(vprob v);
void capteur_valeur_defecteux_hum(vprob v);
void marques_def();
void marques_def_nbr();
int max_marque_def();
term finale(term t,int i);

