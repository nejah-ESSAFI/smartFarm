#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "capteur.h"
#include <string.h>
#include "fonction.h"
#include "graine.h"


graine selected_graine;
GtkWidget *window2;
GtkWidget *window1;
GtkWidget *window4;
GtkWidget *window5;



void
on_homecap_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowcap; 
windowcap=create_Gestion_de_capteurs ();
gtk_widget_show(windowcap);
 
}


void
on_homeouv_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowouvrier; 
windowouvrier=create_GestionOuvriers ();
gtk_widget_show(windowouvrier);
  
}


void
on_homecal_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
 GtkWidget *windowcal; 
windowcal=create_window4 ();
gtk_widget_show(windowcal);
 
}

 
void
on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
graine g;
int b=1;
GtkWidget *input1,*input2,*inputp,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*hiver,*printemps,*ete,*automne;

GtkWidget *existe;
GtkWidget* success;

GtkWidget *label87;
label87=lookup_widget(objet_graphique,"label87");
GtkWidget *label88;
label88=lookup_widget(objet_graphique,"label88");
GtkWidget *label91;
label91=lookup_widget(objet_graphique,"label91");
GtkWidget *label92;
label92=lookup_widget(objet_graphique,"label92");

success=lookup_widget(objet_graphique,"label93");
existe=lookup_widget(objet_graphique,"label94");



input1=lookup_widget(objet_graphique,"entry1");
input2=lookup_widget(objet_graphique,"entry2");
inputp=lookup_widget(objet_graphique,"entry7");
input3=lookup_widget(objet_graphique,"combobox1");

input4=lookup_widget(objet_graphique, "spinbutton1");
input5=lookup_widget(objet_graphique, "spinbutton2");
input6=lookup_widget(objet_graphique, "spinbutton3");

input7=lookup_widget(objet_graphique, "spinbutton4");
input8=lookup_widget(objet_graphique, "spinbutton5");
input9=lookup_widget(objet_graphique, "spinbutton6");


strcpy(g.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(g.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(g.prix,gtk_entry_get_text(GTK_ENTRY(inputp)));

hiver=lookup_widget (objet_graphique,"radiobutton1");
printemps=lookup_widget (objet_graphique,"radiobutton2");
ete=lookup_widget (objet_graphique,"radiobutton3");
automne=lookup_widget (objet_graphique,"radiobutton4");

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(hiver)))
{
strcpy(g.saison,"Hiver");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(printemps)))
{
strcpy(g.saison,"Printemps");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ete)))
{
strcpy(g.saison,"Ete");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(automne)))
{
strcpy(g.saison,"Automne");
}



strcpy(g.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));

g.date_P.j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input4));
g.date_P.m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input5));
g.date_P.a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input6));

g.date_R.j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input7));
g.date_R.m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input8));
g.date_R.a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input9));

if(strcmp(g.id,"")==0){
		  gtk_widget_show (label87);
b=0;
}
else {
		  gtk_widget_hide(label87);
}
if(strcmp(g.nom,"")==0){
		  gtk_widget_show (label88);
b=0;
}
else {
		  gtk_widget_hide(label88);
}
if(strcmp(g.prix,"")==0){
		  gtk_widget_show (label91);
b=0;
}
else {
		  gtk_widget_hide(label91);
}
if(strcmp(g.type,"")==0){
		  gtk_widget_show (label92);
b=0;
}
else {
		  gtk_widget_hide(label92);
}
if(b==1){

        if(exist_graine(g.id)==1)
        {
		gtk_widget_show (existe);
        }
        else 
	{
		gtk_widget_hide (existe);
        	ajouter_graine(g);
		gtk_widget_show (success);
        }

}

}









void
on_button5_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window4, *window2;
window2=lookup_widget(objet,"window2");
gtk_widget_destroy(window4);
window4=create_window4();
gtk_widget_destroy(window2);
gtk_widget_show(window4);

}








void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter iter;
if(gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store),&iter,path))
{
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,0,&str_data,-1);

}
strcpy(selected_graine.id,str_data);

FILE *f;graine G;
f=fopen("graine.bin","rb");
while(!feof(f))
	{
	fread(&G,sizeof(graine),1,f);
	if(strcmp(selected_graine.id,G.id)==0){selected_graine=G;}	
	}
fclose(f);



}








void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;

GtkWidget *window8;
GtkWidget *window;
window= create_window8 ();
gtk_widget_show (window);

}








void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;

GtkWidget *A,*B,*C;

GtkWidget *entry3;
entry3=lookup_widget(button,"entry3");
GtkWidget *entry9;
entry9=lookup_widget(button,"entry9");
GtkWidget *entry10;
entry10=lookup_widget(button,"entry10");


char idd[30];
char nm[30];
char tp[30];

strcpy(idd,gtk_entry_get_text(GTK_ENTRY(entry3)));
strcpy(nm,gtk_entry_get_text(GTK_ENTRY(entry9)));
strcpy(tp,gtk_entry_get_text(GTK_ENTRY(entry10)));


A = lookup_widget (button,"entry3");
B = lookup_widget (button,"entry9");
C = lookup_widget (button,"entry10");

char IDs[20];
char IDx[20];
char IDy[20];

strcpy(IDs,gtk_entry_get_text(GTK_ENTRY(A)));
strcpy(IDx,gtk_entry_get_text(GTK_ENTRY(B)));
strcpy(IDy,gtk_entry_get_text(GTK_ENTRY(C)));

GtkWidget *treeview1;
window2=lookup_widget (button,"window2");


treeview1=lookup_widget (window2,"treeview1");

if((strcmp(idd,"")==0)&&(strcmp(nm,"")==0))
    {
		rechercher_graine_par_TYPE(IDy,treeview1);
    }
    
else if((strcmp(idd,"")==0)&&(strcmp(tp,"")==0))
    {
		rechercher_graine_par_NOM(IDx,treeview1);
    }
    
else if((strcmp(tp,"")==0)&&(strcmp(nm,"")==0))
    {
		rechercher_graine_par_ID(IDs,treeview1);
    }
    
else if(strcmp(idd,"")==0)
    {
		rechercher_par_NOM_et_TYPE(IDx,IDy,treeview1); 
    }

else if(strcmp(nm,"")==0)
    {
		rechercher_par_ID_et_TYPE(IDs,IDy,treeview1); 
    }

else if(strcmp(tp,"")==0)
    {
		rechercher_par_ID_et_NOM(IDs,IDx,treeview1); 
    }

else 
{
    rechercher_graine(IDs,IDx,IDy,treeview1);
}
}






void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2,*H,*P,*E,*A;
GtkWidget *treeview1;
window2=lookup_widget (button,"window2");

treeview1=lookup_widget (window2,"treeview1");
H=lookup_widget (button,"checkbutton1");
P=lookup_widget (button,"checkbutton2");
E=lookup_widget (button,"checkbutton3");
A=lookup_widget (button,"checkbutton4");

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(H)))
{
afficher_saison_H(treeview1);
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(P)))
{
afficher_saison_P(treeview1);
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(E)))
{
afficher_saison_E(treeview1);
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(A)))
{
afficher_saison_A(treeview1);
}

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(H))&& gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(P))&& gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(E))&& gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(A)))
afficher_graine(treeview1);
}

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window3;
GtkWidget *window;
//GtkWidget *Main_Menue;
window = create_window3 ();
gtk_widget_show (window);

graine g;
GtkWidget *id,*nm,*inputp,*tp,*jour_P,*mois_P,*annee_P,*jour_R,*mois_R,*annee_R,*hiver,*printemps,*ete,*automne;

id = lookup_widget (window,"entry5");
nm = lookup_widget (window,"entry6");
inputp = lookup_widget (window,"entry8"); 
tp = lookup_widget (window,"combobox2");

jour_P = lookup_widget (window,"spinbutton12");
mois_P = lookup_widget (window,"spinbutton13");
annee_P = lookup_widget (window,"spinbutton14");

jour_R = lookup_widget (window,"spinbutton15");
mois_R = lookup_widget (window,"spinbutton16");
annee_R = lookup_widget (window,"spinbutton17");

hiver=lookup_widget (window,"radiobutton8");
printemps=lookup_widget (window,"radiobutton9");
ete=lookup_widget (window,"radiobutton10");
automne=lookup_widget (window,"radiobutton11");

gtk_entry_set_text(id,selected_graine.id);
gtk_entry_set_text(nm,selected_graine.nom);
gtk_entry_set_text(inputp,selected_graine.prix);
//gtk_combo_box_set_active_text(tp,selected_graine.type);

gtk_spin_button_set_value(jour_P,selected_graine.date_P.j);
gtk_spin_button_set_value(mois_P,selected_graine.date_P.m);
gtk_spin_button_set_value(annee_P,selected_graine.date_P.a);

gtk_spin_button_set_value(jour_R,selected_graine.date_R.j);
gtk_spin_button_set_value(mois_R,selected_graine.date_R.m);
gtk_spin_button_set_value(annee_R,selected_graine.date_R.a);

if(strcmp(selected_graine.saison,"Hiver")==0)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(hiver),1);
if(strcmp(selected_graine.saison,"Printemps")==0)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(printemps),1);
if(strcmp(selected_graine.saison,"Ete")==0)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ete),1);
if(strcmp(selected_graine.saison,"Automne")==0)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(automne),1);
}






void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *id,*nm,*inputp,*tp,*jour_P,*mois_P,*annee_P,*jour_R,*mois_R,*annee_R,*hiver,*printemps,*ete,*automne;
graine g;


id = lookup_widget (button,"entry5");
nm = lookup_widget (button,"entry6");
inputp= lookup_widget (button,"entry8");
tp = lookup_widget (button,"combobox2");

jour_P = lookup_widget (button,"spinbutton12");
mois_P = lookup_widget (button,"spinbutton13");
annee_P = lookup_widget (button,"spinbutton14");

jour_R = lookup_widget (button,"spinbutton15");
mois_R = lookup_widget (button,"spinbutton16");
annee_R = lookup_widget (button,"spinbutton17");

strcpy(g.id,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(g.nom,gtk_entry_get_text(GTK_ENTRY(nm)));
strcpy(g.prix,gtk_entry_get_text(GTK_ENTRY(inputp)));

strcpy(g.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tp)));
hiver=lookup_widget (button,"radiobutton8");
printemps=lookup_widget (button,"radiobutton9");
ete=lookup_widget (button,"radiobutton10");
automne=lookup_widget (button,"radiobutton11");

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(hiver)))
{
strcpy(g.saison,"Hiver");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(printemps)))
{
strcpy(g.saison,"Printemps");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ete)))
{
strcpy(g.saison,"Ete");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(automne)))
{
strcpy(g.saison,"Automne");
}

g.date_P.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour_P));
g.date_P.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois_P));
g.date_P.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee_P));

g.date_R.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour_R));
g.date_R.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois_R));
g.date_R.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee_R));

supprimer_graine(g);
ajouter_graine(g);


}








void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window3;
window3=lookup_widget(button,"window3");
gtk_widget_destroy(window3);
}








void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1, *window4;
window4=lookup_widget(button,"window4");
gtk_widget_destroy(window1);
window1=create_window1();
gtk_widget_destroy(window4);
gtk_widget_show(window1);
}






void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1, *window4;
window1=lookup_widget(button,"window1");
gtk_widget_destroy(window4);
window4=create_window4();
gtk_widget_destroy(window1);
gtk_widget_show(window4);
}







void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2, *window4;
window4=lookup_widget(button,"window4");
gtk_widget_destroy(window2);
window2=create_window2();
gtk_widget_destroy(window4);
gtk_widget_show(window2);
}


void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window5;

GtkWidget *treeview2;
window5=lookup_widget (button,"window5");

treeview2=lookup_widget (window5,"treeview2");

afficher_type(treeview2);

}


void
on_button17_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window6, *window4;
window4=lookup_widget(button,"window4");
gtk_widget_destroy(window6);
window6=create_window6();
gtk_widget_destroy(window4);
gtk_widget_show(window6);
}


void
on_button20_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window6, *window4;
window6=lookup_widget(button,"window6");
gtk_widget_destroy(window4);
window4=create_window4();
gtk_widget_destroy(window6);
gtk_widget_show(window4);
}


void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window6;
GtkWidget *window5;
GtkWidget *treeview2;

window6=lookup_widget(button,"window6");

gtk_widget_destroy (window6);

window5=lookup_widget(button,"window5");
window5= create_window5();

gtk_widget_show(window5);
}


void
on_button21_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window6, *window5;
window5=lookup_widget(button,"window5");
gtk_widget_destroy(window6);
window6=create_window6();
gtk_widget_destroy(window5);
gtk_widget_show(window6);
}


void
on_button22_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window7;

GtkWidget *treeview3;
window7=lookup_widget (button,"window7");

treeview3=lookup_widget (window7,"treeview3");

afficher_saison(treeview3);
}


void
on_button19_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window6;
GtkWidget *window7;
GtkWidget *treeview2;

window6=lookup_widget(button,"window6");

gtk_widget_destroy (window6);

window7=lookup_widget(button,"window7");
window7= create_window7();

gtk_widget_show(window7);
}


void
on_button23_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window6, *window7;
window7=lookup_widget(button,"window7");
gtk_widget_destroy(window6);
window6=create_window6();
gtk_widget_destroy(window7);
gtk_widget_show(window6);
}


void
on_button25_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;
supprimer_graine(selected_graine);
GtkWidget *window8;
window8=lookup_widget(button,"window8");
gtk_widget_destroy(window8);
}


void
on_button26_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window8;
window8=lookup_widget(button,"window8");
gtk_widget_destroy(window8);

}


void
on_button27_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *label100;
label100=lookup_widget(button,"label100");
GtkWidget *label;
int nb=0 ;
char nbg[20]; 


label=lookup_widget(button,"label99");
nb=nbr_graine() ; 
sprintf(nbg,"%d",nb); 
gtk_label_set_text(GTK_LABEL(label),nbg);
gtk_widget_show (label100);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_buttonListeOuvriers_clicked         (GtkWidget       *button,
                                        gpointer         user_data)
{

GtkWidget *treeview;
GtkWidget *listeouv;
GtkWidget *window;
listeouv = create_ListeOuvriers();
gtk_widget_show(listeouv);
treeview = lookup_widget(listeouv, "treeview");
afficher_Ouvrier(treeview);
window = lookup_widget(button,"GestionOuvriers");
gtk_widget_destroy(window);




}


void
on_buttonSupprimeOuvrier_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowSupprimer;
GtkWidget *windowMenu;
GtkWidget *liste;
windowMenu = lookup_widget(button, "GestionOuvriers");
gtk_widget_destroy(windowMenu);
windowSupprimer = create_SupprimerOuvrier();
gtk_widget_show(windowSupprimer);

liste = lookup_widget (windowSupprimer, "treeview5");
afficher_Ouvrier(liste);

}


void
on_buttonAcceuil_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowSupprimer;
GtkWidget *windowMenu;
GtkWidget *AjoutOuvrier1;
GtkWidget *windowModifier;
GtkWidget *ListeOuvriers1;
GtkWidget *Pointage1;
windowSupprimer = lookup_widget(button, "SupprimerOuvrier");
gtk_widget_destroy(windowSupprimer);

windowModifier = lookup_widget(button, "Modification");
gtk_widget_destroy(windowModifier);

AjoutOuvrier1 = lookup_widget(button, "AjoutOuvrier");
gtk_widget_destroy(AjoutOuvrier1);


ListeOuvriers1 = lookup_widget(button, "ListeOuvriers");
gtk_widget_destroy(ListeOuvriers1);
Pointage1 = lookup_widget(button, "Pointage");
gtk_widget_destroy(Pointage1);


windowMenu = create_GestionOuvriers();
gtk_widget_show(windowMenu);





}


void
on_buttonDeconnexion_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonAjoutOuvrier_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowAjout;
GtkWidget *windowMenu;
windowMenu = lookup_widget(button,"GestionOuvriers");
gtk_widget_destroy(windowMenu);

windowAjout = lookup_widget(button,"AjoutOuvrier");
windowAjout = create_AjoutOuvrier();
gtk_widget_show(windowAjout);






}


void
on_buttonModifOuvrier_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowModifier;
GtkWidget *windowMenu;
GtkWidget *liste;

windowMenu = lookup_widget(button, "GestionOuvriers");
gtk_widget_destroy(windowMenu);
windowModifier = create_ModifierOuvrier();
gtk_widget_show(windowModifier);

liste = lookup_widget (windowModifier, "treeview4");
afficher_Ouvrier(liste);


}

int choix[] = {0,0}; //Homme ou femme pour la fonction ajout Ouvrier
int choix1[] = {0,0};//Homme ou femme pour la fonction Modifier Ouvrier

int i; //variable pour savoir le numero d'identifiant 
void
on_buttonAjouter_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
Ouvrier p;
Ouvrier e;
int fail=0;
FILE *fp1;
fp1 = fopen("utilisateurs.bin", "rb");
if (fp1==NULL)
    {
	i = 0; //Id = 0 si le fichier n'existe pas (pas d'Ouvrier ajouté)
    }
    
 
    else
    {
	while (fread(&p,sizeof(p),1,fp1))
	{
		i = p.id; // i prends la valeur du dernier Ouvrier ajouté
	}
    }
fclose(fp1);
i++; // si le dernier Ouvrier ajouté à un id=5 donc i=6 ou si il nya pas d'Ouvrier, i commence de 1

GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *Jour;
GtkWidget *Mois;
GtkWidget *Annee;
GtkWidget *windowErreur;
GtkWidget *windowSuccees;
GtkWidget *dialog;


input1 = lookup_widget(button, "entryNom");
input2 = lookup_widget(button, "entryPrenom");
input3 = lookup_widget(button, "entryCin");
input4 = lookup_widget(button, "entryGsm");
Jour = lookup_widget(button, "spinbuttonJours");
Mois = lookup_widget(button, "spinbuttonMois");
Annee = lookup_widget(button, "spinbuttonAnnees");


strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.gsm,gtk_entry_get_text(GTK_ENTRY(input4)));

if (choix[0]==1)
strcpy(p.sexe,"Homme");
else if (choix[1]==1)
strcpy(p.sexe,"Femme");


p.date_naissance.jour= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour));
p.date_naissance.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois));
p.date_naissance.annee= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee));
p.id = i;
if(((choix[0]==1) && (choix[1]==1)) || ((choix[0]==0) && (choix[1]==0)) || (strcmp(p.nom,"")==0) || (strcmp(p.prenom,"")==0) || (strcmp(p.cin,"")==0) || (strcmp(p.gsm,"")==0))
{
windowErreur = create_windowChamps();
gtk_widget_show(windowErreur);
fail=1;
}
fp1 = fopen("utilisateurs.bin", "rb");
if(fp1==NULL)
{
	return;
}
else
{
while (fread(&e, sizeof(e), 1, fp1))
{
	if(strcmp(e.cin, p.cin)==0)
	{
		dialog = create_dialog6();
		gtk_widget_show(dialog);
		fail = 1;
		break;
	}
}
fclose(fp1);
}

if (fail==0)
{
ajouter_Ouvrier(p);
windowSuccees = create_dialog1();
gtk_widget_show(windowSuccees);
}

}


void
on_buttonRechercher_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *treeview1;
GtkWidget *liste1;
GtkWidget *input;
GtkWidget *buttonEnable;
GtkWidget *window;
int ok; //variable de la fonction chercher_Ouvrier (1 si existe 0 si existe pas)
Ouvrier e;
char cin[30];
input = lookup_widget(button, "entryUsername");
buttonEnable = lookup_widget(button, "buttonModif"); //Pointeur sur bouton Modifier
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input)));

window = lookup_widget(button, "Modification");
treeview1 = lookup_widget(window, "treeview1");
chercher_Ouvrier(e, cin, &ok);
if (ok)
gtk_widget_set_sensitive(buttonEnable, TRUE); //Set Sensitivity to TRUE
else
gtk_widget_set_sensitive(buttonEnable, FALSE); //Set Sensitivity to FALSE


afficher_OuvrierModif(treeview1);

}


void
on_buttonSupprimer_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
char cin[30];
int id;
GtkWidget *windowSuccees;
Ouvrier p;
Pointage e;
GtkWidget *input;
input = lookup_widget(button, "entryUsername");
strcpy(cin, gtk_entry_get_text(GTK_ENTRY(input)));
id = id_supprimer_Ouvrier(p, cin);
supprimer_Ouvrier(p,cin);
supprimer_pointage(e, id);
windowSuccees = create_dialog3();
gtk_widget_show(windowSuccees);
}


/*void
on_treeview_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{



}
*/

void
on_checkbuttonMale_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix[0] = 1;
else
choix[0] = 0;
}


void
on_checkbuttonFemelle_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix[1] = 1;
else
choix[1] = 0;

}





gboolean
on_treeview_start_interactive_search   (GtkTreeView     *treeview,
                                        gpointer         user_data)
{

  return FALSE;
}


void
on_buttonRefresh_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview;
GtkWidget *listeouv;
listeouv = create_ListeOuvriers();
treeview = lookup_widget(listeouv, "treeview");
afficher_Ouvrier(treeview);


}

char tmps[30];// stocker dans la variable tmps le cin de l'utilisateur a modifier pour l'utiliser dans l'affichage
void
on_buttonModif_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

Ouvrier e;
GtkWidget *input1;
GtkWidget *windowModification;
//char cin[30];
FILE *fp;
fp = fopen("tOuvrier1.bin", "rb");
input1 = lookup_widget(button, "entryUsername");
strcpy(tmps,gtk_entry_get_text(GTK_ENTRY(input1)));
windowModification = create_Modification();
gtk_widget_show(windowModification);
// *********************************	SET TEXT TO ENTRIES	***************************
GtkWidget *output1, *output2, *output3, *output4, *output5, *output6, *output7;
if(fp!=NULL)
{
while (fread(&e, sizeof(e), 1, fp))
{
	output1 = lookup_widget(windowModification, "entryModifierNom");
	gtk_entry_set_text(GTK_ENTRY(output1), e.nom);

	output2 = lookup_widget(windowModification, "entryModifierPrenom");
	gtk_entry_set_text(GTK_ENTRY(output2), e.prenom);

	output3 = lookup_widget(windowModification, "entryModifierCin");
	gtk_entry_set_text(GTK_ENTRY(output3), e.cin);

	output4 = lookup_widget(windowModification, "entryModifierGsm");
	gtk_entry_set_text(GTK_ENTRY(output4), e.gsm);

	output5 = lookup_widget(windowModification, "spinbuttonModifierJour");
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(output5), e.date_naissance.jour);


	output6 = lookup_widget(windowModification, "spinbuttonModifierMois");
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(output6), e.date_naissance.mois);


	output7 = lookup_widget(windowModification, "spinbuttonModifierAnnee");
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(output7), e.date_naissance.annee);

}
}
////////////////////////////////////////////////////////
fclose(fp);
}


void
on_buttonConfirmerModif_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

Ouvrier p;
FILE *fp1;
fp1 = fopen("utilisateurs.bin", "rb");
if (fp1==NULL)
    {
	i = 0;
    }
    
 
    else
    {
	while (fread(&p,sizeof(p),1,fp1))
	{
		if (strcmp(p.cin,tmps)==0){
		i = p.id; // i prends la valeur de l'Ouvrier qui a la cin à rechercher
		break;}
	}
    }

GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *Jour;
GtkWidget *Mois;
GtkWidget *Annee;
GtkWidget *windowErreur;
GtkWidget *windowSuccees;
GtkWidget *windowM;


input1 = lookup_widget(button, "entryModifierNom");
input2 = lookup_widget(button, "entryModifierPrenom");
input3 = lookup_widget(button, "entryModifierCin");
input4 = lookup_widget(button, "entryModifierGsm");
Jour = lookup_widget(button, "spinbuttonModifierJour");
Mois = lookup_widget(button, "spinbuttonModifierMois");
Annee = lookup_widget(button, "spinbuttonModifierAnnee");


strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.gsm,gtk_entry_get_text(GTK_ENTRY(input4)));

if (choix1[0]==1)
strcpy(p.sexe,"Homme");
else if (choix1[1]==1)
strcpy(p.sexe,"Femme");


p.date_naissance.jour= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour));
p.date_naissance.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois));
p.date_naissance.annee= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee));
p.id = i;

if(((choix1[0]==1) && (choix1[1]==1)) || ((choix1[0]==0) && (choix1[1]==0)) || (strcmp(p.nom,"")==0) || (strcmp(p.prenom,"")==0) || (strcmp(p.cin,"")==0) || (strcmp(p.gsm,"")==0))
{
windowErreur = create_windowChamps();
gtk_widget_show(windowErreur);
}
else
{
modifier_Ouvrier(p, tmps);  
windowSuccees = create_dialog2();
gtk_widget_show(windowSuccees);
windowM = lookup_widget(button, "Modification");
gtk_widget_destroy(windowM);
}




}


void
on_checkbuttonModifierMale_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix1[0] = 1;
else
choix1[0] = 0;

}


void
on_checkbuttonModifierFemelle_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix1[1] = 1;
else
choix1[1] = 0;

}


void
on_RechercherSupp_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *treeview2;
GtkWidget *liste1;
GtkWidget *input;
GtkWidget *buttonEnable;
GtkWidget *window;
int ok; //variable de la fonction chercher_Ouvrier (1 si existe 0 si existe pas)
Ouvrier e;
char cin[30];
input = lookup_widget(button, "entryUsername");
buttonEnable = lookup_widget(button, "buttonSupprimer"); //Pointeur sur bouton Modifier
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input)));

window = lookup_widget(button, "SupprimerOuvrier");
treeview2 = lookup_widget(window, "treeview2");
chercher_Ouvrier(e, cin, &ok);
if (ok)
gtk_widget_set_sensitive(buttonEnable, TRUE); //Set Sensitivity to TRUE
else
gtk_widget_set_sensitive(buttonEnable, FALSE); //Set Sensitivity to FALSE


afficher_OuvrierModif(treeview2);

}


void
on_buttonPointage_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Pointage;
GtkWidget *windowMain;
GtkWidget *combobox;//pointeur combobox dynamique
GtkWidget *combobox1;
GtkWidget *buttonEnable;
FILE *fp, *fp2;
Ouvrier e;
char id[30];
fp = fopen("utilisateurs.bin", "rb");
windowMain = lookup_widget(button, "GestionOuvriers");
gtk_widget_destroy(windowMain);
Pointage = create_Pointage();
gtk_widget_show(Pointage);

buttonEnable = lookup_widget(Pointage, "buttonChercherTaux");
combobox = lookup_widget(Pointage, "comboboxentryID");
combobox1 = lookup_widget(Pointage, "comboboxentryIDTaux");
if(fp!=NULL)
{
while (fread(&e,sizeof(e),1,fp))
{
sprintf(id,"%d",e.id); //convert Ouvrier id from int to char 
gtk_combo_box_append_text(GTK_COMBO_BOX(combobox), id); //append id's in combobox from user file(window de Pointage)
gtk_combo_box_append_text(GTK_COMBO_BOX(combobox1), id); //append id's in combobox from user file(window de TAUX)
}
fclose(fp);
}
fp2 = fopen("pointage.bin","rb");
if(fp2==NULL)
{
	gtk_widget_set_sensitive(buttonEnable, FALSE);
}
//fclose(fp2);

}


void
on_buttonCofirmerPointage_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{


Pointage p;
GtkWidget *identifiant;
GtkWidget *spin1, *spin2, *spin3;
GtkWidget *etat;
GtkWidget *dialog;
GtkWidget *buttonEnable;
char tmp[30];

identifiant = lookup_widget(button, "comboboxentryID");
spin1 = lookup_widget(button,"spinbuttonJourPoint");
spin2 = lookup_widget(button,"spinbuttonMoisPoint");
spin3 = lookup_widget(button,"spinbuttonAnneePoint");
etat = lookup_widget(button,"comboboxentryEtat");
buttonEnable = lookup_widget(button, "buttonChercherTaux");

dialog = create_windowChamps();

p.date.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin1));
p.date.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin2));
p.date.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin3));


if((gtk_combo_box_get_active_text(GTK_COMBO_BOX(identifiant))==NULL) || (gtk_combo_box_get_active_text(GTK_COMBO_BOX(etat))==NULL))
{
	gtk_widget_show(dialog);

}
else
{
strcpy(tmp, gtk_combo_box_get_active_text(GTK_COMBO_BOX(identifiant)));
p.Ouvrier.id = atoi(tmp);
strcpy(p.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(etat)));
gtk_widget_set_sensitive(buttonEnable, TRUE);
pointage(p);

}
}


void
on_buttonConsulter_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

Pointage p;
int res;
int x1,x2;
char res1[30];

char id[30];
char ident[30];
GtkWidget *identifiant;
GtkWidget *treeview3;
GtkWidget *label;
label = lookup_widget(button, "labelTaux");
identifiant = lookup_widget(button, "comboboxentryIDTaux");
strcpy(id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(identifiant)));
//treeview3 = lookup_widget(button, "treeview3");
//afficher_taux(treeview3);

	res = tauxABS();
	sprintf(res1, "Taux d'absenteisme : %d%%", res);

gtk_label_set_text(GTK_LABEL(label),res1);


}


void
on_buttonChercherTaux_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview3;
GtkWidget *liste1;
GtkWidget *input;
GtkWidget *buttonEnable;
GtkWidget *dialog;
FILE *fp1, *fp;
fp = fopen("pointage.bin","rb");
fp1 = fopen("calc.bin","wb");
int ok; //variable de la fonction chercher_Ouvrier (1 si existe 0 si existe pas)
int ok1;
Ouvrier e;
Pointage p;
char ident[30];
char id[30];
input = lookup_widget(button, "comboboxentryIDTaux");
buttonEnable = lookup_widget(button, "buttonConsulter"); //Pointeur sur bouton Consulter
dialog = create_dialog5();
if(gtk_combo_box_get_active_text(GTK_COMBO_BOX(input))==NULL)
{
	gtk_widget_show(dialog);
}
else
{
strcpy(ident,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input)));
treeview3 = lookup_widget(button, "treeview3");
chercher_Ouvrier_taux(e, ident, &ok);
check(p, ident, &ok1);
if ((ok) && (ok1))
gtk_widget_set_sensitive(buttonEnable, TRUE); //Set Sensitivity to TRUE
else
gtk_widget_set_sensitive(buttonEnable, FALSE); //Set Sensitivity to FALSE
if((fp1==NULL))
{
return;
}
else
{
	while (fread(&p,sizeof(p),1,fp))
	{
		sprintf(id, "%d", p.Ouvrier.id);
		if(strcmp(id,ident)==0)
		{
		fwrite(&p, sizeof(p), 1 ,fp1);
		}	
	}

}
fclose(fp);
fclose(fp1);

afficher_taux(treeview3, ident);

}
}


void
on_buttonRefreshTaux_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *labelMeilleur;
GtkWidget *liste;
GtkWidget *img;
int identifiantFinal;
int x1, x2;
int res;
int meilleurOuvrier=100;
int id;
char meilleurCh[100];
labelMeilleur = lookup_widget(button, "label66");
img = lookup_widget(button, "image52");
FILE *fp;
Pointage p;
fp = fopen("pointage.bin", "rb");
if(fp==NULL)
{
	return;
}
else
{
while (fread(&p, sizeof(p), 1, fp))
{
	x1 = premier(p.Ouvrier.id);
	deuxieme(p.Ouvrier.id, &x2);
	if(x2==0)
	{
		gtk_label_set_text(GTK_LABEL(labelMeilleur), "Erreur!");
		break;
	}
	else
	{
	res = (x1*100)/x2;
	}
	if(res<meilleurOuvrier)
	{
		meilleurOuvrier = res;
		id = p.Ouvrier.id;
	}
}
sprintf(meilleurCh, "Meilleur Taux : %d%%", meilleurOuvrier);
gtk_label_set_text(GTK_LABEL(labelMeilleur), meilleurCh);
}
fclose(fp);
liste = lookup_widget(button, "treeview6");
afficher_meilleur_Ouvrier(liste, id);
gtk_widget_show(img);


}


void
on_okbutton1_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window = lookup_widget(button, "dialog1");
gtk_widget_destroy(window);


}


void
on_okbutton2_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window = lookup_widget(button, "dialog2");
gtk_widget_destroy(window);

}


void
on_okbutton3_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window = lookup_widget(button, "dialog3");
gtk_widget_destroy(window);

}


void
on_okbutton4_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window = lookup_widget(button, "windowChamps");
gtk_widget_destroy(window);

}


void
on_okbutton5_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window = lookup_widget(button, "dialog5");
gtk_widget_destroy(window);

}


void
on_okbutton6_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window = lookup_widget(button, "dialog6");
gtk_widget_destroy(window);

}


void
on_buttonGenererPire_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *labelPire;
GtkWidget *liste;
GtkWidget *img;
int identifiantFinal;
int x1, x2;
int res;
int pireOuvrier=0;
int id;
char pireCh[100];
labelPire = lookup_widget(button, "label79");
img = lookup_widget(button, "image53");
FILE *fp;
Pointage p;
fp = fopen("pointage.bin", "rb");
if(fp==NULL)
{
	return;
}
else
{
while (fread(&p, sizeof(p), 1, fp))
{
	x1 = premier(p.Ouvrier.id);
	deuxieme(p.Ouvrier.id, &x2);
	if(x2==0)
	{
		gtk_label_set_text(GTK_LABEL(labelPire), "Erreur!");
		break;
	}
	else
	{
	res = (x1*100)/x2;
	}
	if(res>pireOuvrier)
	{
		pireOuvrier = res;
		id = p.Ouvrier.id;
	}
}
sprintf(pireCh, "Pire Taux : %d%%", pireOuvrier);
gtk_label_set_text(GTK_LABEL(labelPire), pireCh);
}
fclose(fp);
liste = lookup_widget(button, "treeview7");
afficher_meilleur_Ouvrier(liste, id);
gtk_widget_show(img);


}

/////////////////////////////////////////////////////////////////////////////////////////////////////////

void
on_valider_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{


capteur c;

GtkWidget *input1,*input4,*input6,*input7;

GtkWidget *JOUR;
GtkWidget *MOIS;
GtkWidget *ANNEE;
GtkWidget *radio1;
GtkWidget *radio2;
GtkWidget *radio3;
GtkWidget *radio4;
GtkWidget *label19;

GtkWidget *output;


GSList *List;

GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);

char msg[500];

FILE *f=NULL;



input1=lookup_widget(object_graphique,"refcap");

input4=lookup_widget(object_graphique,"marque");
input6=lookup_widget(object_graphique,"bp");
input7=lookup_widget(object_graphique,"bs");
JOUR=lookup_widget(object_graphique,"jour");
MOIS=lookup_widget(object_graphique,"mois");
ANNEE=lookup_widget(object_graphique,"annee");
radio1=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton1");
radio2=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton2");
radio3=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton3");
radio4=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton4");

output=lookup_widget(object_graphique,"label19");




List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radio1)); 

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(c.type,gtk_button_get_label(GTK_BUTTON(List->data))); 
else{ List = g_slist_next(List); 
strcpy(c.type,gtk_button_get_label(GTK_BUTTON(List->data)));}

List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radio3)); 

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(c.etat,gtk_button_get_label(GTK_BUTTON(List->data))); 
else {List = g_slist_next(List); 
strcpy(c.etat,gtk_button_get_label(GTK_BUTTON(List->data)));}



strcpy(c.refcapteur,gtk_entry_get_text(GTK_ENTRY(input1)));

strcpy(c.marque,gtk_entry_get_text(GTK_ENTRY(input4)));
c.dda.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(JOUR));
c.dda.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MOIS));
c.dda.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ANNEE));
strcpy(c.bp,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(c.bs,gtk_entry_get_text(GTK_ENTRY(input7)));

int i,k=0,j=0;
for (i=0;i<strlen(c.refcapteur);i++)
if (      (isspace(c.refcapteur[i])!=0) ||  (c.refcapteur[i]=='*')    ) k++;
for (i=0;i<strlen(c.marque);i++)
if (      (isspace(c.marque[i])!=0) ||  (c.marque[i]=='*')    ) j++;



if (strcmp(c.refcapteur,"")==0) {sprintf(msg,"Veuillez saisir REF capteur "); gtk_label_set_text(GTK_LABEL(output),msg);}

else if (rechercher(c)==1) 
	{sprintf(msg,"Ce capteur existe ");
	gtk_label_set_text(GTK_LABEL(output),msg); }

else if (k!=0) 
	{sprintf(msg,"Veuillez changer les espace par des ' _ ' \n dans le champ REF du capteur");

	gtk_label_set_text(GTK_LABEL(output),msg); }
else if (j!=0) 
	{sprintf(msg,"Veuillez changer les espace par des ' _ ' \n et evitez d utiliser le symbole ' * ' \n dans le champ marque du capteur");
	gtk_label_set_text(GTK_LABEL(output),msg); }			
			
else if (strcmp(c.marque,"")==0) {sprintf(msg,"Veuillez saisir la marque du capteur"); gtk_label_set_text(GTK_LABEL(output),msg);}

else { sprintf(msg,"capteur ayant l REF: %s\n ajoutee avec succes",c.refcapteur); gtk_label_set_text(GTK_LABEL(output),msg);
	ajouter_capteur(c); }

}










void
on_valider2_clicked                    (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{


capteur c;
GtkWidget *input;

GtkWidget *output;
char msg[200];




output=lookup_widget(object_graphique,"label18");
input=lookup_widget(object_graphique,"refcapsup");
strcpy(c.refcapteur,gtk_entry_get_text(GTK_ENTRY(input)));

if (strcmp(c.refcapteur,"")==0) {sprintf(msg,"Veuillez saisir REF capteur à supprimer"); gtk_label_set_text(GTK_LABEL(output),msg);}

/*else if (rechercher(c)==0) 
	{ sprintf(msg,"Ce capteur n'existe pas ");gtk_label_set_text(GTK_LABEL(output),msg); }*/

else {supprimer_capteur(c);sprintf(msg,"Donnees du capteur ayant l REF : %s \n sont supprimées", c.refcapteur);gtk_label_set_text(GTK_LABEL(output),msg); }	 




}















void
on_cvmdf_clicked                       (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{

GtkWidget *cmj;
GtkWidget *cmm;
GtkWidget *cma;
GtkWidget *combobox1;
GtkWidget *combobox2;
GtkWidget *input;
GtkWidget *cmarquemdf;
GtkWidget *output;
GtkWidget *refcapmdf;
GtkWidget *bpmdf;
GtkWidget *bsmdf;
char msg[200];

capteur c;


input=lookup_widget(object_graphique,"refcapmdf");
cmarquemdf=lookup_widget(object_graphique,"cmarquemdf");
combobox1=lookup_widget(object_graphique,"combobox1");
combobox2=lookup_widget(object_graphique,"combobox2");
cmj=lookup_widget(object_graphique,"cmj");
cmm=lookup_widget(object_graphique,"cmm");
cma=lookup_widget(object_graphique,"cma");
output=lookup_widget(object_graphique,"label17");
bpmdf=lookup_widget(object_graphique,"bpmdf");
bsmdf=lookup_widget(object_graphique,"bsmdf");



	strcpy(c.refcapteur,gtk_entry_get_text(GTK_ENTRY(input)));
strcpy(c.marque,gtk_entry_get_text(GTK_ENTRY(cmarquemdf)));
int i,k=0,j=0;

for (i=0;i<strlen(c.marque);i++)
if (      (isspace(c.marque[i])!=0) ||  (c.marque[i]=='*')    ) j++;



if (strcmp(c.refcapteur,"")==0) {sprintf(msg,"Veuillez saisir l REF du capteur"); gtk_label_set_text(GTK_LABEL(output),msg);}

else if (rechercher(c)==0) 
	{sprintf(msg,"Ce capteur n existe pas ");
	gtk_label_set_text(GTK_LABEL(output),msg); }

else if ( (    gtk_combo_box_get_active(GTK_COMBO_BOX(combobox1))<0   )|| gtk_combo_box_get_active(GTK_COMBO_BOX(combobox2))<0 || strcmp(c.marque,"")==0 ) 

gtk_label_set_text(GTK_LABEL(output),"veuillez saisir les donnees");

else if (j!=0) 
	{sprintf(msg,"Veuillez changer les espace par des ' _ ' \n et evitez d utiliser le symbole ' * ' \n dans le champ marque du capteur");
	gtk_label_set_text(GTK_LABEL(output),msg); }

else 	
{		
	strcpy(c.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
	strcpy(c.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
	c.dda.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(cmj));
	c.dda.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(cmm));
	c.dda.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(cma));
	strcpy(c.bp,gtk_entry_get_text(GTK_ENTRY(bpmdf)));
	strcpy(c.bs,gtk_entry_get_text(GTK_ENTRY(bsmdf)));	
	modifier_capteur(c);
	sprintf(msg,"Donnes du capteur ayant l REF : %s \n sont modifiees",c.refcapteur);
	gtk_label_set_text(GTK_LABEL(output),msg) ;	
}


}


void
on_caffmdf_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
capteur c;
capteur e;

GtkWidget *input;
GtkWidget *output;
GtkWidget *label17;
GtkWidget *cmarquemdf;
GtkWidget *cmj;
GtkWidget *cmm;
GtkWidget *cma;
GtkWidget *combobox1;
GtkWidget *combobox2;
GtkWidget *bpmdf;
GtkWidget *bsmdf;


char msg[200];

combobox1=lookup_widget(object_graphique,"combobox1");
combobox2=lookup_widget(object_graphique,"combobox2");


cmj=lookup_widget(object_graphique,"cmj");
cmm=lookup_widget(object_graphique,"cmm");
cma=lookup_widget(object_graphique,"cma");


input=lookup_widget(object_graphique,"refcapmdf");
cmarquemdf=lookup_widget(object_graphique,"cmarquemdf");
bpmdf=lookup_widget(object_graphique,"bpmdf");
bsmdf=lookup_widget(object_graphique,"bsmdf");
strcpy(c.refcapteur,gtk_entry_get_text(GTK_ENTRY(input)));
output=lookup_widget(object_graphique,"label17");
if (strcmp(c.refcapteur,"")==0) {sprintf(msg,"Veuillez saisir l REF du capteur"); gtk_label_set_text(GTK_LABEL(output),msg);}
else if (rechercher(c)==0) 
	{sprintf(msg,"Ce capteur n existe pas ");
	gtk_label_set_text(GTK_LABEL(output),msg); }

else {	e=refrechercher(c);
	sprintf(msg,"Modification des donnes du capteur\n ayant l REF : %s ",c.refcapteur);
	/*"%s %s %s %s %d %d %d " , e.refcapteur,e.type,e.etat,e.marque,e.dda.jour,e.dda.mois,e.dda.annee);*/
	gtk_label_set_text(GTK_LABEL(output),msg);
	

	
	if (strcmp(e.type,"temperature")==0) gtk_combo_box_set_active(GTK_COMBO_BOX(combobox1),0);
	else gtk_combo_box_set_active(GTK_COMBO_BOX(combobox1),1);
	if (strcmp(e.etat,"fonctionnel")==0) gtk_combo_box_set_active(GTK_COMBO_BOX(combobox2),0);
	else if (strcmp(e.etat,"en-arret")==0) gtk_combo_box_set_active(GTK_COMBO_BOX(combobox2),1);
	else gtk_combo_box_set_active(GTK_COMBO_BOX(combobox2),2);
	
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(cmj),e.dda.jour);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(cmm),e.dda.mois);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(cma),e.dda.annee);
	gtk_entry_set_text(GTK_ENTRY(cmarquemdf),e.marque);
	gtk_entry_set_text(GTK_ENTRY(bpmdf),e.bp);
	gtk_entry_set_text(GTK_ENTRY(bsmdf),e.bs);
	}

}















void
on_cafficher_clicked                   (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview1;

treeview1=lookup_widget(object_graphique,"treeview1");
afficher_capteur(treeview1);
}


void
on_buttoncap1_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
valeur v;
capteur c;
GtkWidget *entry1;
GtkWidget *entry2;
GtkWidget *label76;
GtkWidget *radiobutton5;
GtkWidget *radiobutton6;
GtkWidget *calendar1;
guint *y;
guint *m;
guint *d;
  guint year, month, day;
char type[50];
char aaa[50];


entry1=lookup_widget(object_graphique,"entry1");
entry2=lookup_widget(object_graphique,"entry2");
label76=lookup_widget(object_graphique,"label76");

radiobutton5=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton5");
radiobutton6=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton6");

GSList *List;
GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);

List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radiobutton5)); 
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data))); 
else{ List = g_slist_next(List); 
strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data)));}

strcpy(v.refcapteur,gtk_entry_get_text(GTK_ENTRY(entry1)));
strcpy(c.refcapteur,gtk_entry_get_text(GTK_ENTRY(entry1)));
strcpy(aaa,gtk_entry_get_text(GTK_ENTRY(entry2)));
v.val=atof(aaa);

///////////////////////////////
calendar1=lookup_widget(GTK_WIDGET(object_graphique),"calendar1");
gtk_calendar_get_date (GTK_CALENDAR (calendar1),
			 &year, &month, &day);

v.j=day;
v.m=month;
v.a=year;

////////////////////////////
int i,j=0;
for (i = 0;aaa[i] != '\0'; i++)
        if (isdigit(aaa[i])!= 0)
            j++;

c=refrechercher(c);


if (   strcmp(v.refcapteur,"")==0) {gtk_label_set_text(GTK_LABEL(label76),"veuillez saisir l REF du capteur");}
else if (rechercher(c)==0) { gtk_label_set_text(GTK_LABEL(label76),"ce capteur n existe pas");}
else if (strcmp(c.etat,"fonctionnel")!=0) {gtk_label_set_text(GTK_LABEL(label76),"Veuillez verifier que ce capteur est fonctionnel");}
else if (strcmp(c.type,type)!=0) {gtk_label_set_text(GTK_LABEL(label76),"veuillez verifier le type correcte de ce capteur");}
else if (strcmp(aaa,"")==0) {gtk_label_set_text(GTK_LABEL(label76),"veuillez saisir la valeur ajoutée");}
else if (j==0) {gtk_label_set_text(GTK_LABEL(label76),"veuillez saisir une valeur entiére");}
else { gtk_label_set_text(GTK_LABEL(label76),"Valeur ajoutée avec succès"); 
	if (strcmp(type,"temperature")==0) ajouter_temperature(v);
	else ajouter_humidite(v);}









}


void
on_buttoncap3_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
//affichage des valeurs d un seul type
GtkWidget *treeview3;
GtkWidget *entry3;
GtkWidget *entry4;
GtkWidget *radiobutton7;
GtkWidget *radiobutton8;
float min,max;
char type[50];

treeview3=lookup_widget(object_graphique,"treeview3");
entry3=lookup_widget(object_graphique,"entry3");
entry4=lookup_widget(object_graphique,"entry4");
radiobutton7=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton7");
radiobutton8=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton8");

GSList *List;
GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);

List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radiobutton7)); 
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data))); 
else{ List = g_slist_next(List); 
strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data)));}

min=atof(gtk_entry_get_text(GTK_ENTRY(entry3)));
max=atof(gtk_entry_get_text(GTK_ENTRY(entry4)));

if (strcmp(type,"temperature")==0) afficher_temperature(treeview3);
else afficher_humidite(treeview3);



}


void
on_buttoncap4_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
//affichage des valeurs d un seul capteur
GtkWidget *treeview3;
GtkWidget *entry5;
char REF[50];
capteur c;

entry5=lookup_widget(object_graphique,"entry5");
treeview3=lookup_widget(object_graphique,"treeview3");
strcpy(REF,gtk_entry_get_text(GTK_ENTRY(entry5)));
strcpy(c.refcapteur,REF);
afficher_valeur_capteur(treeview3,c);


}


void
on_buttoncap5_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
//affichage des valeurs probleme d un seul type hors un intervalle
GtkWidget *treeview3;
GtkWidget *entry3;
GtkWidget *entry4;
GtkWidget *radiobutton7;
GtkWidget *radiobutton8;
vprob v;
char type[50];
v.vmax=0;v.vmin=0;
entry3=lookup_widget(object_graphique,"entry3");
entry4=lookup_widget(object_graphique,"entry4");
treeview3=lookup_widget(object_graphique,"treeview3");

radiobutton7=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton7");
radiobutton8=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton8");

GSList *List;
GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);

List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radiobutton7)); 
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data))); 
else{ List = g_slist_next(List); 
strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data)));}


v.vmin=atof(gtk_entry_get_text(GTK_ENTRY(entry3)));
v.vmax=atof(gtk_entry_get_text(GTK_ENTRY(entry4)));

if (strcmp(type,"humidite")==0) afficher_valeur_probleme_hum(treeview3,v);
else afficher_valeur_probleme_temp(treeview3,v);




}


void
on_buttoncap6_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
//changer type en def si hors l intervalle 
GtkWidget *entry3;
GtkWidget *entry4;
GtkWidget *radiobutton7;
GtkWidget *radiobutton8;
vprob v;
char type[50];
GtkWidget *label72;

label72=lookup_widget(object_graphique,"label72");

entry3=lookup_widget(object_graphique,"entry3");
entry4=lookup_widget(object_graphique,"entry4");


radiobutton7=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton7");
radiobutton8=lookup_widget(GTK_WIDGET(object_graphique),"radiobutton8");

GSList *List;
GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);

List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radiobutton7)); 
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data))); 
else{ List = g_slist_next(List); 
strcpy(type,gtk_button_get_label(GTK_BUTTON(List->data)));}


v.vmin=atof(gtk_entry_get_text(GTK_ENTRY(entry3)));
v.vmax=atof(gtk_entry_get_text(GTK_ENTRY(entry4)));
if (v.vmin==0 || v.vmax==0) gtk_label_set_text(GTK_LABEL(label72),"verifier les valeurs de l intervalle");
else if (strcmp(type,"humidite")==0) capteur_valeur_defecteux_hum(v);
else capteur_valeur_defecteux_temp(v);




}



void
on_buttoncap2_clicked                     (GtkWidget       *object_graphique,
                                        gpointer         user_data)
{
//marque + de cap def 
term t;
char msg[500];
int k;
GtkWidget *label72;

label72=lookup_widget(object_graphique,"label72");

marques_def();
marques_def_nbr();
k=max_marque_def();

t=finale(t,k);
strcpy(msg,t.ter);
if (strcmp(msg,"//////////////*")==0) strcpy(msg,"aucun capteur defectueux");
gtk_label_set_text(GTK_LABEL(label72),msg);



}

/*
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{



	GtkTreeIter iter;
	gchar* refcapteur;
	gchar* type;
	gchar* etat;
	gchar* marque;

	gchar* date;
	gchar* bp;
	gchar* bs;


	capteur c;
	
	GtkTreeModel *model =gtk_tree_view_get_model(treeview);

	if ( gtk_tree_model_get_iter(model,&iter,path)) {
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&refcapteur,1,&type,2,&etat,3,&marque,4,&date,5,&bp,6,&bs,-1);
	strcpy(c.refcapteur,refcapteur);


	
	supprimer_capteur(c);
	afficher_capteur(treeview);
	

	}
}*/






