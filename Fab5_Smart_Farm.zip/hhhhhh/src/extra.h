/*
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{



	GtktreeIter iter;
	gchar* refcapteur;
	gchar* type;
	gchar* etat;
	gchar* marque;

	gchar* date;


	capteur c;
	
GtkTreeModel *model =gtk_tree_view_get_model(treeview);
	if ( gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&refcapteur,1,&type,2,&etat,3,&marque,4,&date,-1);
	strcpy(c.refcapteur,refcapteur);
	strcpy(c.type,type);
	strcpy(c.etat,etat);
	strcpy(c.marque,marque);
	strcpy(c.dda.jour,j);
	strcpy(c.dda.mois,m);
	strcpy(c.dda.annee,a);
	strcat(date,strcpy(j,jr));
	strcart(date,"-");
	strcat(date,strcpy(m,mo));
	strcart(date,"-");
        strcat(date,strcpy(a,an));
	
	
	

afficher_capteur(treeview);

}
}
*/
	f=fopen("humidite.txt","r");
	if(f==NULL)
	{
	return;
	}
	else 
{
	strcpy(type,"humidite");
	f=fopen("humidite.txt","r");
	while(fscanf(f,"%s %s %s %s %s \n",refcapteur,j,m,a,val)!=EOF)
		{if (strcmp(c.refcapteur,refcapteur)==0)
		 {	strcpy(dateval,"");
			strcat(dateval,j);
			strcat(dateval,"/");
			strcat(dateval,m);
			strcat(dateval,"/");
			strcat(dateval,a);
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter,EIDCAPTEUR3,refcapteur,ETYPE3,type,EDATE3,dateval,EVAL3,val,-1);
			}
		}
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
	

}






1 temperature fonctionnel a 1 1 2020 100 70 
2 temperature fonctionnel a 1 1 2020 100 70 
3 temperature fonctionnel b 1 1 2020 100 70 
4 temperature fonctionnel b 1 1 2020 100 70 
5 temperature fonctionnel b 1 1 2020 100 70 
6 temperature fonctionnel c 1 1 2020 100 70
7 temperature fonctionnel c 1 1 2020 100 70
8 temperature fonctionnel d 1 1 2020 100 70
9 temperature fonctionnel d 1 1 2020 100 70
11 humidite fonctionnel d 1 1 2020 100 70
12 humidite fonctionnel d 1 1 2020 100 70
13 humidite fonctionnel c 1 1 2020 100 70
14 humidite fonctionnel c 1 1 2020 100 70
15 humidite fonctionnel c 1 1 2020 100 70
16 humidite fonctionnel b 1 1 2020 100 70
17 humidite fonctionnel b 1 1 2020 100 70
18 humidite fonctionnel b 1 1 2020 100 70
19 humidite fonctionnel a 1 1 2020 100 70




	f=fopen("temperature.txt","r");
	if(f==NULL)
	{
	return;
	}
	else 
{
	f=fopen("temperature.txt","r");
	strcpy(type,"temperature");
	while(fscanf(f,"%s %s %s %s %s \n",refcapteur,j,m,a,val)!=EOF)
{	vvv=atof(val);	
	if (vvv>=v.vmax || vvv<=v.vmin)
{	strcpy(dateval,"");
	strcat(dateval,j);
	strcat(dateval,"/");
	strcat(dateval,m);
	strcat(dateval,"/");
        strcat(dateval,a);
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter,EREFCAPTEUR2,refcapteur,ETYPE2,type,EDATE,dateval,EVAL,val,-1);
}
}
	fclose(f);



/*(	(strcmp(c.type,"temperature")!=0) && (strcmp(c.type,"humidite")!=0) )&&( (strcmp(c.etat,"fonctionnel")!=0) &&
 (strcmp(c.etat,"en-arret")!=0) && (strcmp(c.etat,"defectueux")!=0)	)*/
